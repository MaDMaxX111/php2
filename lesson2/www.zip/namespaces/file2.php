<?
namespace File2;

function test(){
	echo "file2";	
}