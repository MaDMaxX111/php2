<?
include file1();
include file2();

File2\test();