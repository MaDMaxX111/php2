<?
namespace File1;

function test(){
	echo "file1";	
}