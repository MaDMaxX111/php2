<?
trait MyTrait{
	public function test(){
		return $this->name;
	}	
}