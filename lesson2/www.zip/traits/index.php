<?
require "myTrait.php";
require "test1.php";
require "test2.php";

$a = new A();
$a->test();

$b = new B();
$b->test();