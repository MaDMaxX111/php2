<?
include "my_trait.php";

class A{
	private $name = "welcome";
	use MyTrait;	
}