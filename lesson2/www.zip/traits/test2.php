<?
include "my_trait.php";

class B{
	use MyTrait;	
}