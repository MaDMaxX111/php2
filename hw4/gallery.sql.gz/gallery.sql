-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 29 2017 г., 02:06
-- Версия сервера: 5.6.30
-- Версия PHP: 5.5.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `gallery`
--

-- --------------------------------------------------------

--
-- Структура таблицы `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `id` int(11) NOT NULL,
  `file` varchar(255) CHARACTER SET utf8 NOT NULL,
  `size` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `review` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `image`
--

INSERT INTO `image` (`id`, `file`, `size`, `date`, `review`) VALUES
(29, '^57EAD456B9563E57AE205E706956837613A9235DBD6069D6FB^pimgpsh_fullsize_distr-1503983033.jpg', 1119286, '2017-08-29 08:03:53', 0),
(30, '^424B0E7523D87D6C0254D8562DDE3DE96D073400B14B06B043^pimgpsh_fullsize_distr-1503983036.jpg', 1225573, '2017-08-29 08:03:56', 0),
(31, '^5780F211DC6B31B937FCDE8B4683BAE840AEA63F47B0119892^pimgpsh_fullsize_distr-1503983039.jpg', 1173077, '2017-08-29 08:03:59', 0),
(32, '^65405E0957A9572274BDF6815A10AAE0D58096879812F4249F^pimgpsh_fullsize_distr-1503983041.jpg', 884158, '2017-08-29 08:04:01', 0),
(33, '01_base-1503983045.png', 388788, '2017-08-29 08:04:05', 0),
(34, '1-1503983049.png', 706085, '2017-08-29 08:04:09', 0),
(35, '2F-1503983052.jpg', 1341701, '2017-08-29 08:04:12', 0),
(36, '3F-1503983056.jpg', 1319790, '2017-08-29 08:04:16', 0),
(37, '4F-1503983062.jpg', 1343477, '2017-08-29 08:04:22', 0),
(38, '5mgeVKDkG0g-1503983065.jpg', 139553, '2017-08-29 08:04:25', 0),
(39, 'CBt4WosE59I-1503983069.jpg', 127234, '2017-08-29 08:04:29', 0),
(40, 'hbCqjh32h60-1503983075.jpg', 150235, '2017-08-29 08:04:35', 0),
(41, 'hDKC1bDu1V4-1503983080.jpg', 136752, '2017-08-29 08:04:40', 0),
(42, 'i1019^cimgpsh_orig-1503983086.png', 388788, '2017-08-29 08:04:46', 0),
(43, 'logo_best-1503983091.png', 4172, '2017-08-29 08:04:51', 0),
(44, 'QEf0LSMtbNU-1503983099.jpg', 115238, '2017-08-29 08:04:59', 0),
(45, 'Screenshot_1-1503983101.png', 31974, '2017-08-29 08:05:01', 0),
(46, 'vvPoYm8eRqs-1503983106.jpg', 47503, '2017-08-29 08:05:06', 0),
(47, 'YdaOvkudOaw-1503983113.jpg', 206399, '2017-08-29 08:05:13', 0),
(48, 'zgecvlWWAkg-1503983116.jpg', 205777, '2017-08-29 08:05:16', 0),
(49, 'Ð Ð¸ÑÑƒÐ½Ð¾Ðº1-1503983123.jpg', 22975, '2017-08-29 08:05:23', 2),
(50, 'Ð Ð¸ÑÑƒÐ½Ð¾Ðº2-1503983137.png', 246025, '2017-08-29 08:05:37', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
